using System;

namespace Prac2.Models
{
        public class StockQuote
        {
              public string Symbol {get;set;} 
              public int Price {get;set;}
         }
}