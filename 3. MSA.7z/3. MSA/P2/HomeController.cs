using System.Diagnostics;
using Microsoft.AspNetCore.Mvc;
using Prac2.Models;

namespace Prac2.Controllers;

public class HomeController : Controller
{
    public async Task <IActionResult> Index()
           {
                 var model= new StockQuote{ Symbol= "Nike", Price=3200}; 
                 return View(model);
           }

}
