namespace Glossary
{
	public class GlossaryItem
	{
    	public string Term { get; set;}
		public string Definition { get; set; }
	}
}
